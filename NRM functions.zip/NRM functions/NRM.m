function newton_master_all()
    clc; clear;
    fprintf('=== RUNNING ALL 8 NEWTON METHOD TYPES ===\n\n');
    
    % Setup global parameters
    x0 = 1; tol = 1e-5; N = 50;

    %% 1 & 2. Main (Primary) & Local Function Style
    x = x0;
    for k = 1:N
        x_new = x - f_local(x) / fp_local(x); % Calls local functions at the bottom
        if abs(x_new - x) < tol
            fprintf('Type 1 & 2 (Main & Local): Found root %.5f in %d iterations\n', x_new, k);
            break;
        end
        x = x_new;
    end

    %% 3. Nested Function Style
    run_nested_style(x0, tol, N);

    %% 4. Anonymous Function Style
    f_anon = @(x) 1 - 3*x + 0.5*x*exp(x);
    fp_anon = @(x) -3 + 0.5*exp(x) + 0.5*x*exp(x);
    x = x0;
    for k = 1:N
        x_new = x - f_anon(x)/fp_anon(x);
        if abs(x_new - x) < tol
            fprintf('Type 4 (Anonymous):        Found root %.5f in %d iterations\n', x_new, k);
            break;
        end
        x = x_new;
    end
%% 5. private
  function root = privateNRM(x0, tol, N)
    % Demonstration of Newton-Raphson Method
    % f(x) = x^2 - 4, df(x) = 2x

    x = x0;
    for k = 1:N
        % Call the local helper functions defined below
        y = f_local(x);
        dy = fp_local(x);

        % Newton-Raphson update
        x_new = x - y/dy;

        fprintf('Iter %d: x = %.5f\n', k, x_new);

        % Check for convergence
        if abs(x_new - x) < tol
            root = x_new;
            return;
        end
        x = x_new;
    end
    root = x;
    fprintf('Warning: Maximum iterations reached without full convergence.\n');
end

    %% 6. Recursive Function Style
    run_recursive_style(x0, tol, N, 1);

    %% 7. Class Method Style (Automated class file creation)
    setup_class_file();
    clear NewtonSolver; 
    

    %% 8. Callback Function Style (Launches an Interactive UI Window)
    fprintf('\nType 8 (Callback Function): Launching user interface window...\n');
    run_callback_app();
end

%% === NESTED FUNCTION DEMONSTRATION ===
function run_nested_style(x0, tol, N)
    x = x0;
    for k = 1:N
        x_new = x - f_nested(x) / fp_nested(x);
        if abs(x_new - x) < tol
            fprintf('Type 3 (Nested Function):  Found root %.5f in %d iterations\n', x_new, k);
            break;
        end
        x = x_new;
    end
    
    % Nested functions live inside the parent function block
    function y = f_nested(v),  y = 1 - 3*v + 0.5*v*exp(v); end
    function y = fp_nested(v), y = -3 + 0.5*exp(v) + 0.5*v*exp(v); end
end

%% === RECURSIVE FUNCTION DEMONSTRATION ===
function run_recursive_style(x, tol, max_iter, k)
    if k > max_iter, return; end
    f = 1 - 3*x + 0.5*x*exp(x);
    fp = -3 + 0.5*exp(x) + 0.5*x*exp(x);
    x_new = x - f/fp;
    
    if abs(x_new - x) < tol
        fprintf('Type 6 (Recursive):        Found root %.5f in %d iterations\n', x_new, k);
    else
        run_recursive_style(x_new, tol, max_iter, k + 1); % Function calls itself
    end
end

%% === CALLBACK FUNCTION DEMONSTRATION ===
function run_callback_app()
    fig = uifigure('Name', 'Newton Master UI', 'Position', [500 500 300 150]);
    uilabel(fig, 'Text', 'Newton''s Method Callback Demo', 'Position', [45 90 220 20], 'FontWeight', 'bold');
    uibutton(fig, 'Text', 'Click to Calculate Root', 'Position', [60 40 180 30], ...
                  'ButtonPushedFcn', @myUiCallback);
              
    function myUiCallback(~, ~)
        x = 1; tol = 1e-5;
        for k = 1:50
            x_new = x - (1 - 3*x + 0.5*x*exp(x)) / (-3 + 0.5*exp(x) + 0.5*x*exp(x));
            if abs(x_new - x) < tol
                uialert(fig, sprintf('Found Root: %.5f after %d iterations', x_new, k), 'Success!');
                return;
            end
            x = x_new;
        end
    end
end

%% === LOCAL FUNCTIONS ===
function y = f_local(x)
    y = 1 - 3*x + 0.5*x*exp(x);
end

function y = fp_local(x)
    y = -3 + 0.5*exp(x) + 0.5*x*exp(x);
end

%% === AUTOMATED REQUISITE FILE GENERATORS ===
function setup_private_directory()
    if ~exist('private', 'dir'), mkdir('private'); end
    
    fid1 = fopen(fullfile('private', 'f_private.m'), 'w');
    fprintf(fid1, 'function y = f_private(x)\n    y = 1 - 3*x + 0.5*x*exp(x);\nend');
    fclose(fid1);
    
    fid2 = fopen(fullfile('private', 'fp_private.m'), 'w');
    fprintf(fid2, 'function y = fp_private(x)\n    y = -3 + 0.5*exp(x) + 0.5*x*exp(x);\nend');
    fclose(fid2);
end

function setup_class_file()
    fid = fopen('NewtonSolver.m', 'w');
    fprintf(fid, 'classdef NewtonSolver\n');
    fprintf(fid, '    properties\n        Tol = 1e-5\n        N = 50\n    end\n');
    fprintf(fid, '    methods\n');
    fprintf(fid, '        function solve(obj, x0)\n');
    fprintf(fid, '            x = x0;\n');
    fprintf(fid, '            for k = 1:obj.N\n');
    fprintf(fid, '                x_new = x - (1 - 3*x + 0.5*x*exp(x)) / (-3 + 0.5*exp(x) + 0.5*x*exp(x));\n');
    fprintf(fid, '                if abs(x_new - x) < obj.Tol\n');
    fprintf(fid, '                    fprintf(''Type 7 (Class Method):     Found root %%.5f in %%d iterations\\n'', x_new, k);\n');
    fprintf(fid, '                    return;\n');
    fprintf(fid, '                end\n');
    fprintf(fid, '                x = x_new;\n');
    fprintf(fid, '            end\n');
    fprintf(fid, '        end\n');
    fprintf(fid, '    end\n');
    fprintf(fid, 'end\n');
    fclose(fid);
end

